package application;

import controller.ToyController;

public class Main {
    public static void main(String[] args) {
        try {
            ToyController toyController = new ToyController();
            toyController.launchApp(); 
        } catch (Exception e) {
            // Handle exceptions appropriately
            e.printStackTrace();
        }
        
    }
}