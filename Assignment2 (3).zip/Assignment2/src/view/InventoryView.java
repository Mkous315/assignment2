package view;

import model.Toy;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * InventoryView class is used for displaying the toy inventory to the user.
 * It lists all toys, show details of a specific toy, and allow the user
 * to select a toy from the inventory.
 */
public class InventoryView {

    // Method to display all toys in the inventory
    public void displayInventory(ArrayList<Toy> inventory) {
        if (inventory.isEmpty()) {
            System.out.println("The inventory is currently empty.");
            return;
        }

        System.out.println("Inventory:");
        for (int i = 0; i < inventory.size(); i++) {
            System.out.println((i + 1) + ". " + inventory.get(i).toString());
        }
    }

    // Method to display details of a single toy
    public void displayToyDetails(Toy toy) {
        if (toy != null) {
            System.out.println("Toy Details:");
            System.out.println(toy.toString());
        } else {
            System.out.println("Toy not found in the inventory.");
        }
    }

    // Method to select a toy from the inventory
    public Toy selectToyFromInventory(ArrayList<Toy> inventory) {
        if (inventory.isEmpty()) {
            System.out.println("No toys available to select.");
            return null;
        }

        Scanner scanner = new Scanner(System.in);
        int choice = -1;
        while (choice < 1 || choice > inventory.size()) {
            System.out.print("Enter the number of the toy to select (1-" + inventory.size() + "): ");
            try {
                choice = scanner.nextInt();
                scanner.nextLine(); // take newline character
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // take invalid input
                continue;
            }
        }

        return inventory.get(choice - 1);
    }

 
}
