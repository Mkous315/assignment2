package view;

import java.util.ArrayList;
import java.util.Scanner;

import model.Toy;

/**
 * MenuView class handles the interaction with the user, showing different
 * menu options and processing user inputs in the application.
 */
public class MenuView {
    //private static Scanner input = new Scanner(System.in);
    Scanner input = new Scanner(System.in);
    
    public int showMainMenu() {
        //prints welcome message
        System.out.println("*****************************************");
        System.out.println("*\tWELCOME TO TOY STORE COMPANY!\t*");
        System.out.println("*****************************************\\n");
        
        //print main menu options to user
        System.out.println("How May We Help You?\\n");
        System.out.println("\\t(1) Search Inventory and Purchase Toy");
        System.out.println("\\t(2) Add New Toy");
        System.out.println("\\t(3) Remove Toy");
        System.out.println("\\t(4) Save & Exit\\n");
        System.out.print("Enter Option: \\n");
        int option = input.nextInt();
        return option;
    }

    //print search options to user
    public int showSubMenu() {
        System.out.println("Find Toys With:\\n");
        System.out.println("\\t(1) Serial Number(SN)");
        System.out.println("\\t(2) Toy Name");
        System.out.println("\\t(3) Type");
        System.out.println("\\t(4) Back to Main menu\\n");
        System.out.println("Enter option: \\n");
        int option = input.nextInt();
        
        return option;
    }
    
    //method when mainmenu option 2 selected
    // this method add new toys and asks user
    //serial num, toy name, brand, price avail, age, num players, 
    //and designer names
    public Toy addNewToy() {
        // Prompts for adding a new toy
        System.out.print("Enter Serial Number: ");
        input.nextLine();  
        String serialNumber = input.nextLine();

        System.out.print("Enter Toy Name: ");
        String toyName = input.nextLine();
        
        System.out.print("Enter Toy Brand: ");
        String toyBrand = input.nextLine();

        System.out.print("Enter Toy Price: ");
        double toyPrice = input.nextDouble();
        input.nextLine();  

        System.out.print("Enter Available Counts: ");
        int availableCounts = input.nextInt();

        System.out.print("Enter Appropriate Age: ");
        int appropriateAge = input.nextInt();

        System.out.print("Enter Minimum Number of Players: ");
        int minNumOfPlayers = input.nextInt();

        System.out.print("Enter Maximum Number of Players: ");
        int maxNumOfPlayers = input.nextInt();

        input.nextLine();  

        System.out.print("Enter Designer Names (Use ',' to separate the names if there is more than one name): ");
        String designingNames = input.nextLine();

        System.out.println("New Toy Added!");
        System.out.println("Press Enter to Continue...");
        input.nextLine();
        return null;
    }

    //main menu option 3
    //removes toy NOT COMPLETED
    public String removeToy() {
        System.out.print("Enter Serial Number: ");
        String serialNumber = input.nextLine();  // Consume the newline character
        return serialNumber;
        
    }
    
    public void showToyName(Toy toyName) {
        System.out.println(toyName);
    }

    public String promtToyName() {
        System.out.println("Enter name of toy: ");
        String name = input.next();
        return name;
    }
    
    public String promtSN() {
        System.out.println("Enter Serial Number:");
        String sn = input.next();
        return sn;
    }
    
    public void promtError() {
        System.out.println("Error! Please try again.");
        input.nextLine();
        input.nextLine();
    }
    
    public void displayToys(ArrayList<Toy> toysList2) {
        String cate = this.getClass().getName();
        cate = cate.replaceAll("model.", "");
        for (int n=0; n<toysList2.size(); n++) {
            System.out.printf("(%d) %s\\n",n +1 , toysList2.get(n).format());
            //System.out.printf(toysList2.get(n).format());
        }
        
    }

    //ask user for toy type
    public String getType() {
        System.out.println("Enter a toy type: ");
        String type = input.next();
        return type;
    }

}
